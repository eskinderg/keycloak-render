import{f8 as s}from"./main-N0cqCe9S.js";function o(a,r){return s(a,r)}export{o as i};
//# sourceMappingURL=isEqual-CO8fQYt4.js.map
