import{e as s}from"./main-N0cqCe9S.js";const r=()=>s();export{r as u};
//# sourceMappingURL=useParams-C4dyEPv9.js.map
