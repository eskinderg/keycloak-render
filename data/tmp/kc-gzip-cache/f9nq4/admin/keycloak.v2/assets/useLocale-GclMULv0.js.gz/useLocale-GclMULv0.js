import{useMemo as o}from"react";import{c as a,e$ as s}from"./main-N0cqCe9S.js";function u(){const{realmRepresentation:e}=a(),t=o(()=>e?.supportedLocales?.length?e.supportedLocales:[s],[e]),r=o(()=>e?.defaultLocale?.length?[e.defaultLocale]:[],[e]);return o(()=>Array.from(new Set([...r,...t])),[r,t])}export{u};
//# sourceMappingURL=useLocale-GclMULv0.js.map
