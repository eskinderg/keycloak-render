import{d8 as o}from"./main-N0cqCe9S.js";const n=r=>t=>t&&o(r,t)||"—";export{n as t};
//# sourceMappingURL=translationFormatter-ByQb6Dsd.js.map
