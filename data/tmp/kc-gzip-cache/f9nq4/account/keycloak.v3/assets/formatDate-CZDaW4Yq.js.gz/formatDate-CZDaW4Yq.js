import{J as n}from"./main-CsR7Yz67.js";const e={dateStyle:"long"},a={timeStyle:"short"},r={...e,...a};function T(t,o=r){return t.toLocaleString(n.languages,o)}export{T as f};
//# sourceMappingURL=formatDate-CZDaW4Yq.js.map
